int arr[128];
void func(){
  arr[5] = 10;
}
